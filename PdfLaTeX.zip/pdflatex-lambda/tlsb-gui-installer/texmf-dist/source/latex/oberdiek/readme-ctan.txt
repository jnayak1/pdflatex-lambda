README           2016/06/09

This file describes the directory
  CTAN:macros/latex/contrib/oberdiek/

It contains several packages:
  <package>.dtx: source code
  <package>.pdf: documentation

Installation is easier, if you want to install all packages:
Just download
  CTAN:install/macros/latex/contrib/oberdiek.tds.zip
and unzip it in your preferred TDS (texmf) tree.

Hint for attachfile2: This package comes with a Perl script pdfatfi.pl
that should be installed somewhere in PATH as `pdfatfi', see also
package documentation.


Other files in the CTAN directory:
* README: This file.
* oberdiek.tex, oberdiek.pdf:
  Table of contents of all packages in the directory.
  It contains the table of contents and the abstract of the packages.
  The name is a convenience to users of the program `texdoc'.

Happy TeXing
  Heiko Oberdiek <heiko.oberdiek at googlemail.com>

Oberdiek Package Support Group
  ho-tex@tug.org
Preferred bug reporting address is now
  https://github.com/ho-tex/oberdiek/issues